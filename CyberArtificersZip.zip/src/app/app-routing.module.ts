import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginCustomerComponent } from './login-customer/login-customer.component';
import { RegisterCustomerComponent } from './register-customer/register-customer.component';
import { RegisterProfessionalComponent } from './register-professional/register-professional.component';
import { LoginProfessionalComponent } from './login-professional/login-professional.component';
import { HomeComponent } from './home/home.component';




const routes: Routes = [{path: '', component: HomeComponent},
{path: 'loginCustomer', component: LoginCustomerComponent},
{path: 'registerCustomer', component: RegisterCustomerComponent},
{path: 'loginProfessional', component: LoginProfessionalComponent},
{path: 'registerProfessional',  component: RegisterProfessionalComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
