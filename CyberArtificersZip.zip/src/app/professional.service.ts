import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProfessionalService {
  constructor(private httpClient: HttpClient) { }

  registerProfessional(professional: any) {
    console.log(professional);
    return this.httpClient.post('/RESTAPI_CA/webapi/myresource/registerProfessional',  professional);
   }

   getProfByUserPass(loginform : any){
    console.log(loginform);
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/getProfByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }
}
