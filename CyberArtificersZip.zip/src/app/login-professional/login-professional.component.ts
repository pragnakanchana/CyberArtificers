import { Component, OnInit } from '@angular/core';
import { ProfessionalService } from '../professional.service';

@Component({
  selector: 'app-login-professional',
  templateUrl: './login-professional.component.html',
  styleUrls: ['./login-professional.component.css']
})
export class LoginProfessionalComponent implements OnInit {

  
  loginform: any;
  retrivedData : any;
  constructor(private service : ProfessionalService) {
    this.loginform = {emailId : '', password : ''};
   }

  ngOnInit(): void {
  }
  getCustByUserPass() {
    this.service.getProfByUserPass(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
    if(this.retrivedData === null){
      alert("Wrong Credentials");

    }
    });
    }

}
