import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-customer',
  templateUrl: './login-customer.component.html',
  styleUrls: ['./login-customer.component.css'],
})
export class LoginCustomerComponent implements OnInit {

  loginform: any;
  retrivedData : any;
  constructor(private router : Router , private service : CustomerService) {
    this.loginform = {emailId : '', password : ''};
   }

  ngOnInit(): void {
  }
  getCustByUserPass() {
    this.service.getCustByUserPass(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
    if(this.retrivedData === null){
      alert("Wrong Credentials");
    }
    else{
      alert("Logged in");
    }
    });
    }
}
