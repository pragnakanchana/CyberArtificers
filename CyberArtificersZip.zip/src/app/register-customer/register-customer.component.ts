import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

import { Router } from '@angular/router';
@Component({
  selector: 'app-register-customer',
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.css']
})
export class RegisterCustomerComponent implements OnInit {
  
  customer: any;
  constructor(private router: Router,private service: CustomerService) { 
    this.customer = {customerId: '', customerName : '', password: '', emailId: '', mobNum: '', landmark: '',district :'' ,state : '' };
  }

  ngOnInit(): void {
    //console.log("hehhe");
    //console.log(this.customer);
  }

  register(): void {
    console.log(this.customer);
    this.service.registerCustomer(this.customer).subscribe((result: any) => { console.log(result); 
     
    } );
    alert("Registered successfully");
      
    this.router.navigate(['loginCustomer']);
   
  }

}
