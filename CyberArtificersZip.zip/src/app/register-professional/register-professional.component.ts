import { Component, OnInit } from '@angular/core';
import { ProfessionalService } from '../professional.service';

@Component({
  selector: 'app-register-professional',
  templateUrl: './register-professional.component.html',
  styleUrls: ['./register-professional.component.css']
})
export class RegisterProfessionalComponent implements OnInit {
  

  professional: any;
  constructor(private service: ProfessionalService) { 
    this.professional = {professionalId: '', professionalName : '', password: '', emailId: '', mobNum: '', landmark: '',district :'' ,state : '' , expertise : '' , 
    specialization : ''};
  }

  ngOnInit(): void {
    //console.log("hehhe");
    //console.log(this.customer);
  }

  register(): void {
    console.log(this.professional);
    this.service.registerProfessional(this.professional).subscribe((result: any) => { console.log(result); } );
   
  }
}
