import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private httpClient: HttpClient) { }

  registerCustomer(customer: any) {
    console.log(customer);
    return this.httpClient.post('RESTAPI_CA/webapi/myresource/registerCustomer',  customer);
   }

   getCustByUserPass(loginform : any){
    console.log(loginform);
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/getCustByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }
  
}