import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImageUploadingService {

  constructor(private httpClient: HttpClient) { }

  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.append('productName', ImageForm.productName);
    formData.append('description', ImageForm.description);
    formData.append('price', ImageForm.price);

    return this.httpClient.post('RESTAPI_CA/webapi/myresource/uploadImage', formData);
  }

  getProducts() {
   // return this.httpClient.get('RESTAPI_CA/webapi/myresource/getImages').pipe(retry(10));
   }
}
