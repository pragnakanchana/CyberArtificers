import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-edit-profile-customer',
  templateUrl: './edit-profile-customer.component.html',
  styleUrls: ['./edit-profile-customer.component.css']
})
export class EditProfileCustomerComponent implements OnInit {

  customer : any;
  new_customer : any;
  constructor(private service: CustomerService,private router : Router,private _snackBar: MatSnackBar ) { 
    
  }

  ngOnInit(): void {
    this.customer = JSON.parse(localStorage.getItem("customer"));
    console.log(this.customer);
    this.new_customer = this.customer;
  }
  update(){
    this.service.UpdateCustomer(this.new_customer).subscribe((result: any) => { console.log(result); 
      
    } );
    alert("updated !!");
      let message = "Updated !!";
      let action = "";
      this._snackBar.open(message, action, {
      duration: 2000,
      });
      this.router.navigate(['homeComponent']);
  }
  updateemail(email : string){
    this.new_customer.emailId = email;
  }
  updateName(x : string){
    this.new_customer.customerName = x;
    console.log(this.new_customer);
  }
  updateMobnum(x : string){
    this.new_customer.mobNum = x;
  }
  updateLandmark(x : string){
    this.new_customer.landmark = x;
  }

  updateDistrict(x : string){
    this.new_customer.district = x;
  }
  updateState(x : string){
    this.new_customer.state = x;
  }
}
