import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginCustomerComponent } from './login-customer/login-customer.component';
import { RegisterCustomerComponent } from './register-customer/register-customer.component';
import { RegisterProfessionalComponent } from './register-professional/register-professional.component';
import { LoginProfessionalComponent } from './login-professional/login-professional.component';
import { HomeComponent } from './home/home.component';
import { ServicesComponent } from './services/services.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { ShowDbImagesComponent} from './show-db-images/show-db-images.component';
import { EditProfileCustomerComponent } from './edit-profile-customer/edit-profile-customer.component';
import { ViewrequestsComponent } from './viewrequests/viewrequests.component';
import { AboutUsComponent } from './about-us/about-us.component';




const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'homeComponent', component: HomeComponent},
{path: 'loginCustomer', component: LoginCustomerComponent},
{path: 'registerCustomer', component: RegisterCustomerComponent},
{path: 'loginProfessional', component: LoginProfessionalComponent},
{path: 'registerProfessional',  component: RegisterProfessionalComponent},
{path: 'services',  component: ServicesComponent},
{path: 'editProfileCustomer', component: EditProfileCustomerComponent},
{path : 'viewrequests', component : ViewrequestsComponent},
{path : 'about', component : AboutUsComponent}
//{path: 'Upload-image', component : UploadImageComponent},
//{path: 'show-images', component : ShowDbImagesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
