import { Component, OnInit } from '@angular/core';
import { ProfessionalService } from '../professional.service';
import { ViewChild,ElementRef } from '@angular/core'
import { CryptpasswordService } from '../cryptpassword.service' ; 

import { Router } from '@angular/router';
@Component({
  selector: 'app-register-professional',
  templateUrl: './register-professional.component.html',
  styleUrls: ['./register-professional.component.css']
})
export class RegisterProfessionalComponent implements OnInit {
  
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  auth2 : any;
  customer: any;
  name : string;

  professional: any;
  constructor(private pass : CryptpasswordService,private router: Router,private service: ProfessionalService) { 
    this.professional = {professionalId: '', professionalName : '', password: '', emailId: '', mobNum: '', landmark: '',district :'' ,state : '' , expertise : '' , 
    specialization : ''};
  }

  ngOnInit(): void {
    this.googleInitialize();
    console.log(this.name);
    //console.log("hehhe");
    //console.log(this.customer);
  }
  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '1032460484684-vrbgg9me05sbm108em5ta7p3ok4n1hje.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        //this.show = true;
        this.name =  profile.getName();
        localStorage.setItem('customerName',this.name);
      //this.router.navigate(['homeComponent']);
      
        console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
     
      //this.router.navigate(['homeComponent']);
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
    }
      EnCryptpassword(password : string){
        let encryptedText = this.pass.encrypt(password);
        console.log(encryptedText);
        return encryptedText;
        }
        DeCryptpassword(password : string){
        let decryptedText = this.pass.decrypt(password);
        console.log(decryptedText);
        return decryptedText;
        }
  register(): void {
    this.professional.password = this.EnCryptpassword(this.professional.password);
    console.log(this.professional);
    this.service.registerProfessional(this.professional).subscribe((result: any) => { console.log(result); } );
    alert("Registered successfully");
    this.router.navigate(['loginProfessional']);

  }
}