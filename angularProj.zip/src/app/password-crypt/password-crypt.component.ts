import { Component, OnInit } from '@angular/core';
import { CryptpasswordService } from '../cryptpassword.service' ; 

@Component({
  selector: 'app-password-crypt',
  templateUrl: './password-crypt.component.html',
  styleUrls: ['./password-crypt.component.css']
})
export class PasswordCryptComponent implements OnInit {

  constructor(private pass : CryptpasswordService) { }

  ngOnInit(): void {
    let encryptedText = this.pass.encrypt("Hello World");
    console.log(encryptedText);
    let decryptedText = this.pass.decrypt(encryptedText);
    console.log(decryptedText);
  }

}
