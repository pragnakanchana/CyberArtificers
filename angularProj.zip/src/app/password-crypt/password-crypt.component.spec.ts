import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordCryptComponent } from './password-crypt.component';

describe('PasswordCryptComponent', () => {
  let component: PasswordCryptComponent;
  let fixture: ComponentFixture<PasswordCryptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PasswordCryptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordCryptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
