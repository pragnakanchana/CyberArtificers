import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { ProfessionalService } from '../professional.service';
import { HostListener } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(public customerService: CustomerService, public professionalService: ProfessionalService) { }
  
  ngOnInit(): void {
  }
  custLogout(){
    this.customerService.setCustLoggedOut();
    localStorage.clear();
  }
  profLogout(){
    this.professionalService.setProfLoggedOut();
    localStorage.clear();
  }
  
  @HostListener('window:scroll', ['$event'])
onWindowScroll(e) {
    let element = document.querySelector('.navbar');
    if (window.pageYOffset > element.clientHeight) {
      element.classList.add('navbar-inverse');
    } else {
      element.classList.remove('navbar-inverse');
    }
  }
}
