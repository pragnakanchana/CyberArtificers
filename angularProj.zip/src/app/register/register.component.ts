import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  customer: any;
  constructor(private service: CustomerService) { 
    this.customer = {customerId: '', customerName : '', password: '', emailId: '', mobNum: '', landmark: '',district :'' ,state : '' };
  }

  ngOnInit(): void {
    console.log("hehhe");
    console.log(this.customer);
  }

  register(): void {
    console.log(this.customer);
    this.service.registerCustomer(this.customer).subscribe((result: any) => { console.log(result); } );
   
  }
}
