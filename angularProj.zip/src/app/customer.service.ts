import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  isCustLoggedIn : any;
  constructor(private httpClient: HttpClient) {
    this.isCustLoggedIn = false;
   }
   
   setCustLoggedIn(): void { // login success
    this.isCustLoggedIn = true;
   }
   setCustLoggedOut(): void { // logout success
    this.isCustLoggedIn = false;
   }
   getCustLogged(): any {
     return this.isCustLoggedIn;
   }
  registerCustomer(customer: any) {
    console.log(customer);
    return this.httpClient.post('RESTAPI_CA/webapi/myresource/registerCustomer',  customer);
   }

   getCustByUserPass(loginform : any){
    console.log(loginform);
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/getCustByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }

   UpdateCustomer(customer: any){
    console.log(customer);
    return this.httpClient.post('RESTAPI_CA/webapi/myresource/UpdateCustomerProfile',  customer);
   }
   getCustByEmail(loginform : any){
    console.log("hehehe");
    console.log(loginform.emailId);
    
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/getCustByEmail/'+ loginform.emailId);
   }

   getAllCustomers(){
     return this.httpClient.get('RESTAPI_CA/webapi/myresource/getCustomers');
   }
   getAllServices(){
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/getServices');
  }
}