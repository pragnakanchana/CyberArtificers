import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RegisterComponent } from './register/register.component';
import { LoginCustomerComponent } from './login-customer/login-customer.component';
import { RegisterCustomerComponent } from './register-customer/register-customer.component';
import { RegisterProfessionalComponent } from './register-professional/register-professional.component';
import { LoginProfessionalComponent } from './login-professional/login-professional.component';
import { HomeComponent } from './home/home.component';
import { StorageServiceModule } from 'ngx-webstorage-service';
import { FormsModule } from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import {MatChipsModule} from '@angular/material/chips';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { ServicesComponent } from './services/services.component';
import { GoogleLoginComponent } from './google-login/google-login.component';
import { PasswordCryptComponent } from './password-crypt/password-crypt.component';
import { FooterComponent } from './footer/footer.component';
import {MatExpansionModule} from '@angular/material/expansion';
import { EditProfileCustomerComponent } from './edit-profile-customer/edit-profile-customer.component';
import { ViewrequestsComponent } from './viewrequests/viewrequests.component';
import { AboutUsComponent } from './about-us/about-us.component';
/*import { UploadImageComponent } from './upload-image/upload-image.component';
import { ShowDbImagesComponent} from './show-db-images/show-db-images.component';
*/
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    RegisterComponent,
    LoginCustomerComponent,
    RegisterCustomerComponent,
    RegisterProfessionalComponent,
    LoginProfessionalComponent,
    HomeComponent,
    ServicesComponent,
    GoogleLoginComponent,
    PasswordCryptComponent,
    FooterComponent,
    EditProfileCustomerComponent,
    ViewrequestsComponent,
    AboutUsComponent,
    //ShowDbImagesComponent,
    //UploadImageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule ,
     HttpClientModule,
     BrowserAnimationsModule,StorageServiceModule,
     MatChipsModule,
     ToastrModule,
    AppRoutingModule,
    MatSnackBarModule,
    MatToolbarModule,
    MatIconModule,
    MatExpansionModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
