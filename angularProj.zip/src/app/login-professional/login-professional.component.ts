import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { ProfessionalService } from '../professional.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ViewChild,ElementRef } from '@angular/core'
import { CryptpasswordService } from '../cryptpassword.service' ; 

@Component({
  selector: 'app-login-professional',
  templateUrl: './login-professional.component.html',
  styleUrls: ['./login-professional.component.css']
})
export class LoginProfessionalComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;

  
  auth2 : any;
  loginform: any;
  retrivedData : any;
  durationInSeconds = 5;
  name : string = null;

  constructor(private pass : CryptpasswordService,private router : Router , private service : ProfessionalService,private _snackBar: MatSnackBar) {
    this.loginform = {emailId : '', password : ''};
   }

  ngOnInit(): void {
    this.googleInitialize();
    console.log(this.name);
  }
  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '1032460484684-vrbgg9me05sbm108em5ta7p3ok4n1hje.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        //this.show = true;
        this.name =  profile.getName();
        localStorage.setItem('customerName',this.name);
      //this.router.navigate(['homeComponent']);
      
      console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        
      //this.router.navigate(['homeComponent']);
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }

  EnCryptpassword(password : string){
    let encryptedText = this.pass.encrypt(password);
    //console.log(encryptedText);
    return encryptedText;
  }
  
  DeCryptpassword(password : string){
    let decryptedText = this.pass.decrypt(password);
    console.log(decryptedText);
    return decryptedText;
  }
  getProfByUserPass() {
    let original_password = this.loginform.password;
    console.log("checking.....");
    //console.log(this.EnCryptpassword(original_password));
    //this.loginform.password = this.EnCryptpassword(this.loginform.password);
    console.log("loginform in login.ts............");
    console.log(this.loginform);
    this.service.getProfByEmail(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
     //console.log(this.retrivedData);
     let decrypted_pass = this.DeCryptpassword(this.retrivedData.password);
     //console.log(decrypted_pass);
      if(this.loginform.password != decrypted_pass || this.retrivedData == null){
      alert("Wrong Credentials");
      }
      else{
        let message = "Logged in !!";
        let action = "";
        this._snackBar.open(message, action, {
        duration: 2000,
      });
      //console.log(this.retrivedData.customerName);
      this.name = this.retrivedData.customerName;
      localStorage.setItem('professional',JSON.stringify(result));
      this.router.navigate(['homeComponent']);
    }
    });
    }



}
