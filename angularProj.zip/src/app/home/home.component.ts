import { Component, OnInit } from '@angular/core';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  customer : any;
  check : boolean = false;
  customerName : string = null;
  constructor() { }

  ngOnInit(): void {
    
    this.customer = JSON.parse(localStorage.getItem("customer"));
    this.customerName = this.customer.customerName;
    console.log("heheh");
    console.log(this.customerName);
     /* if(localStorage.getItem("customerName") === null){
          this.check = false;
      }
      else{
        this.check = true;
      }*/
      
  }

  showShortDesciption = true
  text = "Read more";
  alterDescriptionText() {
     this.showShortDesciption = !this.showShortDesciption
     if(this.showShortDesciption){
       this.text = "Read more";
     }
     else{
       this.text = "Read Less";
     }
  }
}
