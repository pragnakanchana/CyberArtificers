import { Component, OnInit } from '@angular/core';
import { ProfessionalService } from '../professional.service';
import {MatExpansionModule} from '@angular/material/expansion';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  service : any;
  customer : any;
  panelOpenState = false;
  constructor(private s: ProfessionalService) {
    this.service = {serviceId : '', problem : '', scheduledDate : '', slot : '', status : '', customer : {}, professional : {}};
   }
  problems = ['FAULTY HEADLIGHTS AND TAILLIGHTS','TIRE BLOWOUTS','FAULTY STEERING SYSTEM AND SUSPENSION', 'MALFUNCTIONING WIPERS', 'FAULTY BRAKES'];
  times = ['10:00 AM to 12:00 PM','12:00 AM to 2:00 PM','2:00 AM to 4:00 PM','4:00 AM to 6:00 PM']
  body : string;
  cid : any;
  ngOnInit(): void {
    this.service.professional = null;
    this.customer = JSON.parse(localStorage.getItem("customer"));
    this.service.customer = this.customer;
    this.cid = this.customer.customerId;
    this.body = this.customer.customerName + ", A customer needs ur service, if u r interested please login to ur account and accept the request !!";
  }
  subject = "Service Notification ";
  
  storedata() {
    console.log(this.service);
    this.s.updateDetailsInService(this.service).subscribe((result: any) => { console.log(result); } );
    //this.s.sendSMS().subscribe((result: any) => { console.log(result); } );
    //this.s.mail(this.cid,this.subject,this.body).subscribe((result: any) => { console.log(result); } );
    //alert("Updated successfully");
  }
  updateTimeSlot(y : string){
    alert(y);
      this.service.slot = y;
  }
  
  updateProblem(x : string){
    //alert(x);
    this.service.problem = x;
}
step = 0;

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }
}
