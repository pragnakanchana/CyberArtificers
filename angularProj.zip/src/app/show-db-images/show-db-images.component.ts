import { Component, OnInit } from '@angular/core';
import { ImageUploadingService } from '../image-uploading.service';

@Component({
  selector: 'app-show-db-images',
  templateUrl: './show-db-images.component.html',
  styleUrls: ['./show-db-images.component.css']
})
export class ShowDbImagesComponent implements OnInit {

  products: any;

  constructor(private service: ImageUploadingService) { }

  ngOnInit() {
    //this.service.getProducts().subscribe( (result: any) => {console.log(result); this.products = result; });
  }

}
