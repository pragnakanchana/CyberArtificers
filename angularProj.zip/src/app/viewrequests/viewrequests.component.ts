import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { ProfessionalService } from '../professional.service';

@Component({
  selector: 'app-viewrequests',
  templateUrl: './viewrequests.component.html',
  styleUrls: ['./viewrequests.component.css']
})
export class ViewrequestsComponent implements OnInit {

  constructor(private service:ProfessionalService, private cs:CustomerService) { }

  ngOnInit(): void {
    this.displayRequests();
  }

  requests = {};
  pid = "5";
  displayRequests(){
    this.service.viewRequests(this.pid).subscribe((result: any) => {
      console.log(result);   
      this.requests = result;
     });
    
  }

  data : any;
  customerName : string;
  custPhnum : string;
  service_data : any;
  professional:any;
  rid:any;
  Accept(){
    this.professional = JSON.parse(localStorage.getItem("professional"));
    this.service.updateRequestStatus(this.rid, '1').subscribe((result:any) => {
      console.log(result);
    });
  }
  Reject(){
    this.professional = JSON.parse(localStorage.getItem("professional"));
    this.service.updateRequestStatus(this.rid, '0').subscribe((result:any) => {
      console.log(result);
    });
  }
  viewdetails(request : any){
    
    console.log("rid....");
    console.log(request);
    this.rid = request.rId;
    console.log(this.rid);
    this.cs.getAllCustomers().subscribe((result:any) =>{
      this.data = result;
      
      this.data.forEach(i => {

          if(i.customerId == request.cid){
            this.customerName = i.customerName
            this.custPhnum = i.mobNum;
          }
      })
      console.log(this.customerName);
        
    });

    this.cs.getAllServices().subscribe((result:any) =>{
      this.data = result;
      this.data.forEach(i => {
          if(i.serviceId == request.sid){
            this.service_data = i;
          }
      })
      
      console.log(this.service_data);
      console.log(this.customerName);
        
    });
  }
}
