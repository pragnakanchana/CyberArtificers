import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProfessionalService {


  isProfLoggedIn : any;
  constructor(private httpClient: HttpClient) {
    this.isProfLoggedIn = false;
   }
   
   setProfLoggedIn(): void { // login success
    this.isProfLoggedIn = true;
   }
   setProfLoggedOut(): void { // logout success
    this.isProfLoggedIn = false;
   }
   getProfLogged(): any {
     return this.isProfLoggedIn;
   }
    registerProfessional(professional: any) {
    console.log(professional);
    return this.httpClient.post('/RESTAPI_CA/webapi/myresource/registerProfessional',  professional);
    }


   updateDetailsInService(service : any){

    console.log(service);
    return this.httpClient.post('/RESTAPI_CA/webapi/myresource/updateServices',  service);
   }
   sendSMS(){
     console.log("received iin service");
     return this.httpClient.get('/RESTAPI_CA/webapi/myresource/sendSMS');
   }
   
   mail(cid: any, subject: any, body : any){
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/mail/'+ cid + '/' + subject + '/' + body );
    }
   getProfByUserPass(loginform : any){
    console.log(loginform);
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/getProfByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }
   
   getProfByEmail(loginform : any){
    console.log("hehehe");
    console.log(loginform.password);
    return this.httpClient.get('RESTAPI_CA/webapi/myresource/getProfByEmail/'+ loginform.emailId);
   }

   viewRequests(pid : string){
     console.log(pid);
     return this.httpClient.get('RESTAPI_CA/webapi/myresource/ViewRequests/'+pid);
   }

   updateRequestStatus(rid : string, x : string){
     
      return this.httpClient.get('RESTAPI_CA/webapi/myresource/updateRequestStatus/'+rid + '/' + x);
   }
   
}
